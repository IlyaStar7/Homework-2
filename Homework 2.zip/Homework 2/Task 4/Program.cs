﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            string TrueLogin = "root";
            string TruePassword = "GeekBrains";

            do
            {
                Console.WriteLine("Введите Логин");
                string Login = Console.ReadLine();

                Console.WriteLine("Введите Пароль");
                string Password = Console.ReadLine();

                a++;
                if(TrueLogin == Login && TruePassword == Password)
                {
                    Console.WriteLine("Логин и Пароль введены верно, Добро Пожаловать");
                    break;
                }
                else
                {
                    Console.WriteLine("Вы ошиблись. Количество попыток - " + (3 - a));
                    continue;
                }
            }
            while (a < 3);

            if(a == 3)
            {
                Console.WriteLine("Все попытки потрачены. Возвращайтесь через 24 часа");
            }

            // Так же решил никуда не подглядывать и выполнить так, как кажется правильным. Надеюсь, Вы оцените)

            Console.ReadLine();

        }
    }
}
