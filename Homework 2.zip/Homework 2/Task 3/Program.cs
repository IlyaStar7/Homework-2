﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_3
{
    class Program
    {
        static void Main(string[] args)
        {
            // 3. С клавиатуры вводятся числа, пока не будет введен 0. Подсчитать сумму всех нечетных положительных чисел

            int a, number;

            Console.WriteLine("Введите любое число от -1 000 до 1 000.");
            number = Convert.ToInt32(Console.ReadLine());
            a = number;

            while (number !=0)
            {
                Console.WriteLine("Введите любое число от -1 000 до 1 000.");
                number = Convert.ToInt32(Console.ReadLine());
                if(number % 2 !=0 && number > 0)
                {
                    a = a + number;
                }
            }

            // Решил не подсматривать решение в уроке 3. Не знаю правильным ли методом составлено решение
            // но, вроде бы, код рабочий)

            Console.WriteLine("Сумма всех нечётных положительных чисел = " + a);
            Console.ReadLine();
        }
    }
}
