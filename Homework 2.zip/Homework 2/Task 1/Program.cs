﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_1
{
    class Program
    {
        static void Main(string[] args)
        {

            // C # Уровень 1
            // Захаров Илья. (Здаю дз с опозданием)
            // 1. Написать метод, возвращающий минимальное из трех чисел

            int a, b, c, min;
            Console.WriteLine("Введите 1-е число:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите 2-е число:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите 3-е число:");
            c = Convert.ToInt32(Console.ReadLine());

            min = a;

            if(a<=b && a<=c)
            {
                min = a;
            }
            else if(b<=c && b<=a)
            {
                min = b;
            }
            else if(c<=a && c<=b)
            {
                min = c;
            }

            // Заметил, что если не поставить <=, а просто <, то программа может выдать, что мин число A
            // при условии, что B=C, а A больше.

            Console.WriteLine("Самое маленькое число - {0}", min);
            Console.ReadLine();
        }
    }
}
