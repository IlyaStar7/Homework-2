﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_2
{
    class Program
    {
        static void Main(string[] args)
        {
            // 2. Написать метод подсчета количества цифр числа

            Console.WriteLine("Введите целое число:");
            int a = Convert.ToInt32(Console.ReadLine());

            int count = 0;

            while(a !=0)
            {
                count++;
                a = a / 10;
            }

            Console.WriteLine(count);
            Console.ReadLine();
        }
    }
}
